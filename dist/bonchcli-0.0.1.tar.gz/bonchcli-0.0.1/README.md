# BonchCLI

## Установка

```bash
pipx install bonchcli
```

> Это херня пока работает только с Селениумом, так что придётся поставить его, пока я не решил тикет [#5](https://github.com/KarimullinArthur/BonchAPI/issues/5])

### Selemium driver
Если сидишь на Харче можешь бахнуть

```
sudo pacman -S chromium
```

Я надеюсь как можно быстрее избавиться от этой фигни, так что подробно даже писать не хочу.
## Использование

```
usage: bonchcli [-h] [week_offset]

positional arguments:
  week_offset  a positive or negative number

options:
  -h, --help   show this help message and exit

Example: bonchcli -3
```
